# Realtime multiplayer game template

## Uses Godot for the client and NodeJS with ws for the server

### To start the server:

`cd server && npm install && npm start`

### To start the game:

Import it into Godot using the project dialog